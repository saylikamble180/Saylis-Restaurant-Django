"""
Package for RestaurantProject.
"""
